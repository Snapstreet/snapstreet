export class sellerUser {
    key: string;
  Name:string;
  Email:any;
  DOB : any;
  Phone:any;
   active = true;
  UserId: any;
}