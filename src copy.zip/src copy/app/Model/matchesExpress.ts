export class expressMatches {
    key: string;
    ExpressLookingpostcode: any;
    expressLookingState:any;
    expressLookingTown:any;
    expressNoRooms:any;
    expressPropertyCondition:any;
    expressMaxAmount:any;
    expressLookingStreetname:any;
    expressownership:any;
   expressPropertyType:any;
   expressfeatures:any;
   expressValidity:any;
   expressSearchRadius:any;
   active = true;
}