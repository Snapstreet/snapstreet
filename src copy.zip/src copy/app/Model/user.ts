export class user {
    key: string;
  Name:string;
  Email:any;
  DOB : any;
  Phone:any;
   active = true;
 
}