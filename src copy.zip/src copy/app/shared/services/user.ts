export interface User {
    uid: string;
    email: string;
    Name:string;
    DOB:Date;
    Phone:string;
}
