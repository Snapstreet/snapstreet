import { Component, OnInit } from '@angular/core';
import { SelectAgentService } from './select-agent.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { notification } from "../../../Model/notification";
import { Router, ActivatedRoute } from "@angular/router";
import { Location } from "@angular/common";
import { SelectedMyMatchesService } from "../my-matches-selected-details/selected-my-matches.service"
@Component({
  selector: 'app-select-agent',
  templateUrl: './select-agent.component.html',
  styleUrls: ['./select-agent.component.css']
})
export class SelectAgentComponent implements OnInit {
  color = 'accent';
  checked = true;
  disabled = false;
  accepted: boolean = false
  user: any;
  uid: any;
  disable: boolean = true
  agents = [];
  notification: notification;
  now: Date = new Date();
  return: any
  propertyId: any;
  sub: any;
  UserId: any;
  matchesSeller: any;
  Lookingpostcode: any;
  Lookingstate: any;
  LookingAddress: any;
  norooms: any;
  PropertyCondition: any;
  MinAmount: any;
  PropertyType: any;
  ownership: any;
  features: any;
  matchStatus: any;
  MaxAmount: any;
  expressed: any;
  userId: any;
  sellerProperty:any
  matchesBuyer: any;
  seller_Selected_propertydetail_Service: any;
  isSellerSelected: boolean;
  datastored: boolean;
  express: boolean;
  Amount: any;
  
  constructor(public AgentService: SelectAgentService, private _Activatedroute: ActivatedRoute,
    private _location: Location, private _router: Router, private SelectedMyMatchesService: SelectedMyMatchesService) { }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem("user"));
    this.uid = this.user.uid;

    this.sub = this._Activatedroute.paramMap.subscribe((params) => {
      this.Lookingpostcode = params.get("Lookingpostcode");
      this.Lookingstate = params.get("Lookingstate");
      this.LookingAddress = params.get("LookingAddress");
      this.norooms = params.get("Roomsmax");
      this.PropertyCondition = params.get("PropertyCondition");
      this.MaxAmount = params.get("MaxAmount");
      this.PropertyType = params.get("PropertyType");
      this.ownership = params.get("ownership");
      this.features = params.get("features");
      this.propertyId = params.get("propertyId");
      this.UserId = params.get("userId").trim()
      console.log(this.UserId)
    });
    this.AgentService.getAgent(this.uid).subscribe((ref) => {
      ref.forEach(elements => {
        this.agents.push(elements.data())
      })
    })

    this.AgentService.getMatchesSellerProperties(this.UserId).then((res) => {
      res.forEach((element) => {
        this.sellerProperty = (element.data());
        console.log(this.sellerProperty)

        this.Amount = this.sellerProperty.MaxAmount
        console.log(this.Amount)
      });


    });
  }
  Acceptterms() {
    this.accepted = true;
    this.disable = false
  }
  uncheckterms() {
    this.accepted = false;
    this.disable = true
  }
  addToExpressCollection() {
    this.return = this.AgentService.ExpressInterest(
      this.uid,
      this.propertyId.trim()
    ).then((data) => {
      if (data == true) {
        this.createSellerNotification();
      }
    });
  }
  backClicked() {
    this._location.back();
  }
  createSellerNotification() {
    console.log(this.UserId)
    this.notification = {
      time: this.now,
      viewed: "Confirmed",
      userId: this.uid,
      Type: "Agent_Matches_Confirmed",
      propertyId: this.propertyId.trim()
    }
    this.return = this.AgentService
      .createNotification(this.UserId, this.notification)
      .then(data => {
        this.createBuyerEntry()
        this._router.navigate(["/mymatches"]);
      });
  }
  createBuyerEntry() {
  
    this.matchesBuyer = {
      LookingAddress: this.sellerProperty.LookingAddress,
      LookingTown: this.sellerProperty.LookingTown,
      Lookingpostcode: this.sellerProperty.Lookingpostcode,
      Lookingstate: this.sellerProperty.Lookingstate,
      MaxAmount: this.sellerProperty.MaxAmount,
      Maxbathrooms: this.sellerProperty.Maxbathrooms,
      Maxreception: this.sellerProperty.Maxreception,
      Roomsmax: this.sellerProperty.Maxrooms,
      PropertyCondition: this.sellerProperty.PropertyCondition,
      PropertyType: this.sellerProperty.PropertyType,
      UserId: this.sellerProperty.UserId,
      features: this.sellerProperty.features,
      matchStatus: "confirm_interest",
      ownership: this.sellerProperty.ownership, 
    };
    this.return = this.AgentService
      .matchesBuyerCreate(this.UserId, this.matchesBuyer)
      .then((data) => {
        if (data == true) {
        }
      });
  }

}
